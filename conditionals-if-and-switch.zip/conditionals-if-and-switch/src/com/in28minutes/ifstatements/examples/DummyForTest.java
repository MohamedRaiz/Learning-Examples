package com.in28minutes.ifstatements.examples;

public class DummyForTest {

	public void doSomething() {
		// TODO Auto-generated method stub

	}

}
