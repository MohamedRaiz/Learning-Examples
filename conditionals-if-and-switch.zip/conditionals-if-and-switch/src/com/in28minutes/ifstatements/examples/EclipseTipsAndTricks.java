package com.in28minutes.ifstatements.examples;

import java.math.*;

class Test implements Comparable<String> {
//This exercise is about control 1 function
	@Override
	public int compareTo(String arg0) {
		return 0;
	}
}

public class EclipseTipsAndTricks {

	public static void main(String[] args) throws InterruptedException {
		DummyForTest dt = new DummyForTest();
		dt.doSomething();

		BigDecimal bd = new BigDecimal(25);
		int i = 1000 * 45 * 456;
		Thread.sleep(i);

	}

}
