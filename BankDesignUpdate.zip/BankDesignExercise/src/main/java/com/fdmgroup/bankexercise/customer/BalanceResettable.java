package com.fdmgroup.bankexercise.customer;

public interface BalanceResettable {

	void resetBalance();
}
