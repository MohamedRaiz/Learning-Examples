package com.fdmgroup.bankexercise.customer;

public interface SameAmountToAll {

	void addSameAmountToAll(int amountToBeAdded);
}
