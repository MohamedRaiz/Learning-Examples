package com.fdmgroup.bankexercise.account;

public interface InterestRateChangeable {

	public double changeInterestRate(double newInterest);

}
