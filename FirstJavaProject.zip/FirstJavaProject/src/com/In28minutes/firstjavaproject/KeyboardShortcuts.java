package com.In28minutes.firstjavaproject;

public class KeyboardShortcuts {

	public static void main(String[] args) {
		System.out.println("System out println");
	}

}
